Comic Ink is inspired by comic book hand lettering. Enjoy!

Free for personal use only. For commercial licensing please purchase pro version, http://comicink.blogspot.com/
Thanks!

Contact Info:
Michael Hassler(Hassified)
https://www.facebook.com/scott.hassler.art/

